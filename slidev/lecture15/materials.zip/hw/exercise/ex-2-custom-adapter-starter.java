package com.example.listviewexercise;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class CityAdapter extends BaseAdapter {

    private Context context;
    private List<City> cityList;

    public CityAdapter(Context context, List<City> cityList) {
        this.context = context;
        this.cityList = cityList;
    }

    @Override
    public int getCount() {
        // TODO 1: 返回列表项的总数
        return 0;
    }

    @Override
    public Object getItem(int position) {
        // TODO 2: 返回指定位置的数据对象
        return null;
    }

    @Override
    public long getItemId(int position) {
        // TODO 3: 返回指定位置的 ID
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // TODO 4: 实现 ViewHolder 模式
        //   - 如果 convertView 为 null，加载布局并创建 ViewHolder
        //   - 否则，从 convertView.getTag() 取出 ViewHolder
        //   - 填充数据到视图
        //   - 返回 convertView

        return null;
    }

    // TODO 5: 创建 static class ViewHolder，包含 imgCity, tvName, tvCountry
}
