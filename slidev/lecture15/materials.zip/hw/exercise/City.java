package com.example.listviewexercise;

public class City {
    private String name;
    private String country;
    private int imageResId;

    public City(String name, String country, int imageResId) {
        this.name = name;
        this.country = country;
        this.imageResId = imageResId;
    }

    public String getName() { return name; }
    public String getCountry() { return country; }
    public int getImageResId() { return imageResId; }
}
