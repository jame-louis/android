package com.example.listviewexercise;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // TODO 1: 准备数据 —— 创建一个包含 6 种动物的 String 数组
        String[] animals = { /* 在此填入动物名称 */ };

        // TODO 2: 创建 ArrayAdapter
        // 参数：context, 行布局, 数据
        ArrayAdapter<String> adapter = /* 在此创建 Adapter */;

        // TODO 3: 找到 ListView 并设置 Adapter
        ListView lvAnimals = /* findViewById */;
        /* 设置 Adapter */

        // TODO 4: 设置点击事件，点击后在 Toast 中显示动物名称
        /* lvAnimals.setOnItemClickListener(...) */
    }
}
