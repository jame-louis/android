package com.example.listviewexercise;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[] animals = {"猫", "狗", "兔子", "老虎", "大象", "熊猫"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            this,
            android.R.layout.simple_list_item_1,
            animals
        );

        ListView lvAnimals = findViewById(R.id.lvAnimals);
        lvAnimals.setAdapter(adapter);

        lvAnimals.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String selected = animals[position];
                Toast.makeText(MainActivity.this,
                    "你选择了: " + selected, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
