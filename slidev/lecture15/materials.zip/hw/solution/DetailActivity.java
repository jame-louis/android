package com.example.listviewexercise;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Intent intent = getIntent();
        String name = intent.getStringExtra("city_name");
        String country = intent.getStringExtra("city_country");
        String desc = intent.getStringExtra("city_desc");
        int imageResId = intent.getIntExtra("city_image", 0);

        ImageView imgDetail = findViewById(R.id.imgDetail);
        TextView tvName = findViewById(R.id.tvDetailName);
        TextView tvCountry = findViewById(R.id.tvDetailCountry);
        TextView tvDesc = findViewById(R.id.tvDetailDesc);
        Button btnBack = findViewById(R.id.btnBack);

        imgDetail.setImageResource(imageResId);
        tvName.setText(name);
        tvCountry.setText(country);
        tvDesc.setText(desc);

        btnBack.setOnClickListener(v -> finish());
    }
}
