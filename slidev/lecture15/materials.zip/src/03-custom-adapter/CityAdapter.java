package com.example.listviewdemo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class CityAdapter extends BaseAdapter {

    private Context context;
    private List<City> cityList;

    public CityAdapter(Context context, List<City> cityList) {
        this.context = context;
        this.cityList = cityList;
    }

    @Override
    public int getCount() {
        return cityList.size();
    }

    @Override
    public Object getItem(int position) {
        return cityList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                .inflate(R.layout.item_city, parent, false);

            holder = new ViewHolder();
            holder.imgCity = convertView.findViewById(R.id.imgCity);
            holder.tvName = convertView.findViewById(R.id.tvCityName);
            holder.tvCountry = convertView.findViewById(R.id.tvCountry);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        City city = cityList.get(position);
        holder.imgCity.setImageResource(city.getImageResId());
        holder.tvName.setText(city.getName());
        holder.tvCountry.setText(city.getCountry());

        return convertView;
    }

    static class ViewHolder {
        ImageView imgCity;
        TextView tvName;
        TextView tvCountry;
    }
}
