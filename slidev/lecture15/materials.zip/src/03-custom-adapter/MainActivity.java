package com.example.listviewdemo;

import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView lvCities = findViewById(R.id.lvCities);

        List<City> cityList = new ArrayList<>();
        cityList.add(new City("北京", "中国", "中国的首都", R.drawable.beijing));
        cityList.add(new City("巴黎", "法国", "浪漫之都", R.drawable.paris));
        cityList.add(new City("东京", "日本", "日本首都", R.drawable.tokyo));
        cityList.add(new City("纽约", "美国", "世界金融中心", R.drawable.newyork));
        cityList.add(new City("伦敦", "英国", "英国首都", R.drawable.london));
        cityList.add(new City("悉尼", "澳大利亚", "南半球最大城市", R.drawable.sydney));

        CityAdapter adapter = new CityAdapter(this, cityList);
        lvCities.setAdapter(adapter);
    }
}
