package com.example.cityexplorer;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView lvCities;
    private List<City> cityList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvCities = findViewById(R.id.lvCities);
        initCityData();

        CityAdapter adapter = new CityAdapter(this, cityList);
        lvCities.setAdapter(adapter);

        lvCities.setOnItemClickListener((parent, view, position, id) -> {
            City city = cityList.get(position);
            Intent intent = new Intent(MainActivity.this, DetailActivity.class);
            intent.putExtra("city_name", city.getName());
            intent.putExtra("city_country", city.getCountry());
            intent.putExtra("city_desc", city.getDescription());
            intent.putExtra("city_image", city.getImageResId());
            startActivity(intent);
        });
    }

    private void initCityData() {
        cityList = new ArrayList<>();
        cityList.add(new City("北京", "中国",
            "中华人民共和国的首都，拥有故宫、长城等世界文化遗产。", R.drawable.beijing));
        cityList.add(new City("巴黎", "法国",
            "浪漫之都，拥有埃菲尔铁塔、卢浮宫等著名景点。", R.drawable.paris));
        cityList.add(new City("东京", "日本",
            "日本首都，现代与传统完美融合的国际大都市。", R.drawable.tokyo));
        cityList.add(new City("纽约", "美国",
            "世界金融中心，自由女神像和时代广场所在地。", R.drawable.newyork));
        cityList.add(new City("伦敦", "英国",
            "英国首都，大本钟和泰晤士河享誉世界。", R.drawable.london));
        cityList.add(new City("悉尼", "澳大利亚",
            "南半球最大城市，悉尼歌剧院是其标志性建筑。", R.drawable.sydney));
    }
}
