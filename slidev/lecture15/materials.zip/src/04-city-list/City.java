package com.example.cityexplorer;

public class City {
    private String name;
    private String country;
    private String description;
    private int imageResId;

    public City(String name, String country, String description, int imageResId) {
        this.name = name;
        this.country = country;
        this.description = description;
        this.imageResId = imageResId;
    }

    public String getName() { return name; }
    public String getCountry() { return country; }
    public String getDescription() { return description; }
    public int getImageResId() { return imageResId; }
}
