package com.example.listviewdemo;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView lvCities = findViewById(R.id.lvCities);

        // 准备数据
        List<Map<String, Object>> data = new ArrayList<>();

        Map<String, Object> item1 = new HashMap<>();
        item1.put("name", "北京");
        item1.put("country", "中国");
        item1.put("image", R.drawable.beijing);
        data.add(item1);

        Map<String, Object> item2 = new HashMap<>();
        item2.put("name", "巴黎");
        item2.put("country", "法国");
        item2.put("image", R.drawable.paris);
        data.add(item2);

        Map<String, Object> item3 = new HashMap<>();
        item3.put("name", "东京");
        item3.put("country", "日本");
        item3.put("image", R.drawable.tokyo);
        data.add(item3);

        String[] from = {"image", "name", "country"};
        int[] to = {R.id.imgCity, R.id.tvCityName, R.id.tvCountry};

        SimpleAdapter adapter = new SimpleAdapter(
            this, data, R.layout.item_city_simple, from, to
        );

        lvCities.setAdapter(adapter);
    }
}
