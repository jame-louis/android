package com.example.listviewdemo;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. 准备数据
        String[] fruits = {"苹果", "香蕉", "橙子", "葡萄", "西瓜", "芒果", "草莓", "梨", "桃子", "樱桃"};

        // 2. 创建 Adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            this,
            android.R.layout.simple_list_item_1,
            fruits
        );

        // 3. 绑定到 ListView
        ListView lvFruits = findViewById(R.id.lvFruits);
        lvFruits.setAdapter(adapter);

        // 4. 点击事件
        lvFruits.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String selected = fruits[position];
                Toast.makeText(MainActivity.this,
                    "你选择了: " + selected, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
