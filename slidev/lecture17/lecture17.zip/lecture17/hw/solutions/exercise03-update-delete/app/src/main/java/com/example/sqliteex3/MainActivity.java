package com.example.sqliteex3;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

/**
 * Exercise 3: Update and Delete
 * Demonstrates update, delete, and list all operations
 */
public class MainActivity extends AppCompatActivity {

    private UserDao userDao;
    private EditText etUserId, etUsername, etPassword, etEmail;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userDao = new UserDao(this);

        // Initialize views
        etUserId = findViewById(R.id.etUserId);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etEmail = findViewById(R.id.etEmail);
        tvResult = findViewById(R.id.tvResult);

        Button btnInsert = findViewById(R.id.btnInsert);
        Button btnUpdate = findViewById(R.id.btnUpdate);
        Button btnDelete = findViewById(R.id.btnDelete);
        Button btnList = findViewById(R.id.btnList);

        // Insert sample data
        btnInsert.setOnClickListener(v -> insertSampleData());

        // Update user
        btnUpdate.setOnClickListener(v -> {
            String idStr = etUserId.getText().toString().trim();
            String email = etEmail.getText().toString().trim();

            if (idStr.isEmpty()) {
                Toast.makeText(this, "Please enter user ID", Toast.LENGTH_SHORT).show();
                return;
            }

            User user = new User();
            user.setId(Long.parseLong(idStr));
            user.setEmail(email);

            int rows = userDao.updateUser(user);
            tvResult.setText("Updated " + rows + " row(s)");
        });

        // Delete user
        btnDelete.setOnClickListener(v -> {
            String idStr = etUserId.getText().toString().trim();

            if (idStr.isEmpty()) {
                Toast.makeText(this, "Please enter user ID", Toast.LENGTH_SHORT).show();
                return;
            }

            int rows = userDao.deleteUser(Long.parseLong(idStr));
            tvResult.setText("Deleted " + rows + " row(s)");
        });

        // List all users
        btnList.setOnClickListener(v -> {
            List<User> users = userDao.getAllUsers();
            StringBuilder sb = new StringBuilder();
            sb.append("Total ").append(users.size()).append(" users:\n\n");

            for (User u : users) {
                sb.append("ID:").append(u.getId())
                  .append(" | ").append(u.getUsername())
                  .append(" | ").append(u.getEmail())
                  .append("\n");
            }

            tvResult.setText(sb.toString());
        });
    }

    private void insertSampleData() {
        // Insert 3 sample users
        User u1 = new User("alice", "123456", "alice@example.com");
        User u2 = new User("bob", "123456", "bob@example.com");
        User u3 = new User("charlie", "123456", "charlie@example.com");

        userDao.insertUser(u1);
        userDao.insertUser(u2);
        long id3 = userDao.insertUser(u3);

        tvResult.setText("Sample data inserted!\nThird user ID: " + id3);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userDao.close();
    }
}
