package com.example.sqliteex3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

/**
 * User Data Access Object
 * Encapsulates all operations on the users table
 */
public class UserDao {

    private DatabaseHelper dbHelper;

    public UserDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    /**
     * Insert a user
     * @param user User object
     * @return Inserted row ID, -1 indicates failure
     */
    public long insertUser(User user) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", user.getUsername());
        values.put("password", user.getPassword());
        values.put("email", user.getEmail());
        values.put("created_at", user.getCreatedAt());

        return db.insert("users", null, values);
    }

    /**
     * Update user information
     * @param user User object (must contain id)
     * @return Number of affected rows
     */
    public int updateUser(User user) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("email", user.getEmail());

        return db.update(
                "users",
                values,
                "id = ?",
                new String[]{String.valueOf(user.getId())}
        );
    }

    /**
     * Update password
     */
    public int updatePassword(long userId, String newPassword) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("password", newPassword);

        return db.update(
                "users",
                values,
                "id = ?",
                new String[]{String.valueOf(userId)}
        );
    }

    /**
     * Delete user
     * @param userId User ID
     * @return Number of affected rows
     */
    public int deleteUser(long userId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        return db.delete(
                "users",
                "id = ?",
                new String[]{String.valueOf(userId)}
        );
    }

    /**
     * Get all users
     * @return List of users
     */
    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(
                "users",
                null, null, null, null, null,
                "created_at DESC"  // Order by registration time, descending
        );

        if (cursor.moveToFirst()) {
            do {
                userList.add(cursorToUser(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return userList;
    }

    /**
     * Find user by username
     */
    public User findByUsername(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(
                "users",
                null,
                "username = ?",
                new String[]{username},
                null, null, null
        );

        User user = null;
        if (cursor.moveToFirst()) {
            user = cursorToUser(cursor);
        }
        cursor.close();
        return user;
    }

    /**
     * Convert Cursor to User object
     */
    private User cursorToUser(Cursor cursor) {
        User user = new User();
        user.setId(cursor.getLong(cursor.getColumnIndexOrThrow("id")));
        user.setUsername(cursor.getString(cursor.getColumnIndexOrThrow("username")));
        user.setPassword(cursor.getString(cursor.getColumnIndexOrThrow("password")));
        user.setEmail(cursor.getString(cursor.getColumnIndexOrThrow("email")));
        user.setCreatedAt(cursor.getLong(cursor.getColumnIndexOrThrow("created_at")));
        return user;
    }

    public void close() {
        dbHelper.close();
    }
}
