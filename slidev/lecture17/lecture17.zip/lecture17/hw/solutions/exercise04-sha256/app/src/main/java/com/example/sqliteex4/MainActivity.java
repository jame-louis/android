package com.example.sqliteex4;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Exercise 4: SHA-256 Encryption
 * Demonstrates password hashing for secure storage
 */
public class MainActivity extends AppCompatActivity {

    private UserDao userDao;
    private EditText etPassword;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userDao = new UserDao(this);

        etPassword = findViewById(R.id.etPassword);
        tvResult = findViewById(R.id.tvResult);

        Button btnHashDemo = findViewById(R.id.btnHashDemo);
        Button btnRegister = findViewById(R.id.btnRegister);
        Button btnLogin = findViewById(R.id.btnLogin);

        // Hash demo
        btnHashDemo.setOnClickListener(v -> {
            String password = etPassword.getText().toString();
            if (password.isEmpty()) {
                Toast.makeText(this, "Please enter password", Toast.LENGTH_SHORT).show();
                return;
            }

            String hash = HashUtil.sha256(password);
            tvResult.setText(
                    "Original: " + password + "\n\n" +
                    "SHA-256 Hash:\n" + hash + "\n\n" +
                    "Length: " + hash.length() + " characters"
            );
        });

        // Register with encryption
        btnRegister.setOnClickListener(v -> {
            String username = "testuser";
            String password = etPassword.getText().toString();

            if (password.isEmpty()) {
                Toast.makeText(this, "Please enter password", Toast.LENGTH_SHORT).show();
                return;
            }

            User user = new User(username, password, "test@test.com");
            long id = userDao.insertUser(user);

            if (id > 0) {
                tvResult.setText(
                        "Registration successful!\nID: " + id + "\n\n" +
                        "Password stored in DB:\n" + HashUtil.sha256(password) + "\n\n" +
                        "(Even if DB is viewed, original password is not visible)"
                );
            } else {
                tvResult.setText("Registration failed");
            }
        });

        // Login verification
        btnLogin.setOnClickListener(v -> {
            String username = "testuser";
            String password = etPassword.getText().toString();

            User user = userDao.findByUsernameAndPassword(username, password);

            if (user != null) {
                tvResult.setText("Login successful!\nWelcome " + user.getUsername());
            } else {
                tvResult.setText("Login failed: Wrong password or user does not exist");
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userDao.close();
    }
}
