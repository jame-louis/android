package com.example.sqliteex4;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * User Data Access Object
 * Uses SHA-256 encryption for password storage
 */
public class UserDao {

    private DatabaseHelper dbHelper;

    public UserDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    /**
     * Insert user with encrypted password
     */
    public long insertUser(User user) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", user.getUsername());
        // Encrypt password before storing
        values.put("password", HashUtil.sha256(user.getPassword()));
        values.put("email", user.getEmail());
        values.put("created_at", user.getCreatedAt());

        return db.insert("users", null, values);
    }

    /**
     * Find user by username
     */
    public User findByUsername(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(
                "users",
                null,
                "username = ?",
                new String[]{username},
                null, null, null
        );

        User user = null;
        if (cursor.moveToFirst()) {
            user = cursorToUser(cursor);
        }
        cursor.close();
        return user;
    }

    /**
     * Login verification using hash comparison
     */
    public User findByUsernameAndPassword(String username, String password) {
        // First find user by username
        User user = findByUsername(username);

        if (user != null) {
            // Verify password hash
            if (HashUtil.verifyPassword(password, user.getPassword())) {
                return user;
            }
        }
        return null;
    }

    /**
     * Update password with encryption
     */
    public int updatePassword(long userId, String newPassword) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        // Encrypt new password
        values.put("password", HashUtil.sha256(newPassword));

        return db.update(
                "users",
                values,
                "id = ?",
                new String[]{String.valueOf(userId)}
        );
    }

    /**
     * Convert Cursor to User object
     */
    private User cursorToUser(Cursor cursor) {
        User user = new User();
        user.setId(cursor.getLong(cursor.getColumnIndexOrThrow("id")));
        user.setUsername(cursor.getString(cursor.getColumnIndexOrThrow("username")));
        user.setPassword(cursor.getString(cursor.getColumnIndexOrThrow("password")));
        user.setEmail(cursor.getString(cursor.getColumnIndexOrThrow("email")));
        user.setCreatedAt(cursor.getLong(cursor.getColumnIndexOrThrow("created_at")));
        return user;
    }

    public void close() {
        dbHelper.close();
    }
}
