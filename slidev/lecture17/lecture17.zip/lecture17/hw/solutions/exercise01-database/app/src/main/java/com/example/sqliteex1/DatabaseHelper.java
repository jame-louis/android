package com.example.sqliteex1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * 数据库帮助类
 * 管理数据库创建和版本升级
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";

    // 数据库名称和版本
    private static final String DATABASE_NAME = "app.db";
    private static final int DATABASE_VERSION = 1;

    // 建表语句
    private static final String CREATE_USERS_TABLE =
            "CREATE TABLE users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "username TEXT UNIQUE NOT NULL, " +
                    "password TEXT NOT NULL, " +
                    "email TEXT, " +
                    "created_at INTEGER DEFAULT 0" +
            ")";

    /**
     * 构造函数
     * @param context 应用上下文
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * 数据库首次创建时调用
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d(TAG, "Creating database...");
        db.execSQL(CREATE_USERS_TABLE);
        Log.d(TAG, "Users table created successfully");
    }

    /**
     * 数据库版本升级时调用
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d(TAG, "Upgrading database from " + oldVersion + " to " + newVersion);
        // 简单处理：删除旧表，创建新表
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }
}
