package com.example.sqliteex1;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Exercise 1: 数据库创建演示
 * 验证数据库是否成功创建
 */
public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = findViewById(R.id.tvStatus);
        Button btnCreateDb = findViewById(R.id.btnCreateDb);
        Button btnCheckDb = findViewById(R.id.btnCheckDb);
        Button btnCloseDb = findViewById(R.id.btnCloseDb);

        // 创建数据库按钮
        btnCreateDb.setOnClickListener(v -> {
            dbHelper = new DatabaseHelper(this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            tvStatus.setText("数据库创建成功!\n路径: " + db.getPath());
            Toast.makeText(this, "数据库已创建", Toast.LENGTH_SHORT).show();
        });

        // 检查数据库按钮
        btnCheckDb.setOnClickListener(v -> {
            if (dbHelper == null) {
                tvStatus.setText("错误: 请先点击'创建数据库'");
                return;
            }
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            tvStatus.setText("数据库状态:\n" +
                    "路径: " + db.getPath() + "\n" +
                    "是否只读: " + db.isReadOnly() + "\n" +
                    "是否打开: " + db.isOpen());
        });

        // 关闭数据库按钮
        btnCloseDb.setOnClickListener(v -> {
            if (dbHelper != null) {
                dbHelper.close();
                tvStatus.setText("数据库已关闭\n" +
                        "请使用 Device File Explorer 查看:\n" +
                        "/data/data/com.example.sqliteex1/databases/app.db");
                Toast.makeText(this, "数据库已关闭", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}
