package com.example.loginapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Register Activity
 * Handles new user registration with validation
 */
public class RegisterActivity extends AppCompatActivity {

    private UserDao userDao;
    private EditText etUsername, etPassword, etConfirmPassword, etEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        userDao = new UserDao(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        etEmail = findViewById(R.id.etEmail);
        Button btnRegister = findViewById(R.id.btnRegister);
        TextView tvLogin = findViewById(R.id.tvLogin);

        // Register button
        btnRegister.setOnClickListener(v -> {
            if (validateInput()) {
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();
                String email = etEmail.getText().toString().trim();

                // Check if username already exists
                if (userDao.isUsernameExists(username)) {
                    etUsername.setError("Username already exists");
                    return;
                }

                // Create user
                User user = new User(username, password, email);
                long id = userDao.insertUser(user);

                if (id > 0) {
                    Toast.makeText(this, "Registration successful! Please login.", Toast.LENGTH_SHORT).show();
                    finish(); // Go back to login
                } else {
                    Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Login link
        tvLogin.setOnClickListener(v -> {
            finish(); // Go back to login
        });
    }

    /**
     * Validate user input
     * @return true if all fields are valid
     */
    private boolean validateInput() {
        boolean isValid = true;

        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();
        String email = etEmail.getText().toString().trim();

        // Username validation
        if (username.isEmpty()) {
            etUsername.setError("Username is required");
            isValid = false;
        } else if (username.length() < 3) {
            etUsername.setError("Username must be at least 3 characters");
            isValid = false;
        }

        // Password validation
        if (password.isEmpty()) {
            etPassword.setError("Password is required");
            isValid = false;
        } else if (password.length() < 6) {
            etPassword.setError("Password must be at least 6 characters");
            isValid = false;
        }

        // Confirm password
        if (!password.equals(confirmPassword)) {
            etConfirmPassword.setError("Passwords do not match");
            isValid = false;
        }

        // Email validation (optional but must be valid if provided)
        if (!email.isEmpty() && !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Please enter a valid email");
            isValid = false;
        }

        return isValid;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userDao.close();
    }
}
