package com.example.loginapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Adapter for User ListView
 * Displays user information in a custom layout
 */
public class UserListAdapter extends BaseAdapter {

    private List<User> users;
    private LayoutInflater inflater;
    private SimpleDateFormat dateFormat;

    public UserListAdapter(android.content.Context context, List<User> users) {
        this.users = users;
        this.inflater = LayoutInflater.from(context);
        this.dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
    }

    @Override
    public int getCount() {
        return users.size();
    }

    @Override
    public Object getItem(int position) {
        return users.get(position);
    }

    @Override
    public long getItemId(int position) {
        return users.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = inflater.inflate(android.R.layout.simple_list_item_2, parent, false);
            holder = new ViewHolder();
            holder.tvUsername = convertView.findViewById(android.R.id.text1);
            holder.tvDetails = convertView.findViewById(android.R.id.text2);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        User user = users.get(position);
        holder.tvUsername.setText(user.getUsername());

        String dateStr = dateFormat.format(new Date(user.getCreatedAt()));
        holder.tvDetails.setText("ID: " + user.getId() + " | Email: " + user.getEmail() +
                " | Registered: " + dateStr);

        return convertView;
    }

    public void updateList(List<User> newUsers) {
        this.users = newUsers;
        notifyDataSetChanged();
    }

    private static class ViewHolder {
        TextView tvUsername;
        TextView tvDetails;
    }
}
