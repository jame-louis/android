package com.example.loginapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Home Activity
 * Main screen after successful login
 */
public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Get logged in user info
        SharedPreferences prefs = getSharedPreferences(LoginActivity.PREFS_NAME, MODE_PRIVATE);
        String username = prefs.getString(LoginActivity.KEY_USERNAME, "User");

        TextView tvWelcome = findViewById(R.id.tvWelcome);
        Button btnUserList = findViewById(R.id.btnUserList);
        Button btnLogout = findViewById(R.id.btnLogout);

        // Display welcome message
        tvWelcome.setText("Welcome, " + username + "!\n\nYou have successfully logged in.\nThis is the home screen.");

        // User list button
        btnUserList.setOnClickListener(v -> {
            startActivity(new Intent(this, UserListActivity.class));
        });

        // Logout button
        btnLogout.setOnClickListener(v -> {
            // Clear login session
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear();
            editor.apply();

            Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();

            // Go back to login
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    @Override
    public void onBackPressed() {
        // Prevent going back to login with back button
        // User must use logout button
        moveTaskToBack(true);
    }
}
