package com.example.loginapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

/**
 * User List Activity
 * Displays all registered users with delete functionality
 */
public class UserListActivity extends AppCompatActivity {

    private UserDao userDao;
    private ListView listView;
    private UserListAdapter adapter;
    private long currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_list);

        // Enable back button in action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("User List");
        }

        // Get current user ID
        SharedPreferences prefs = getSharedPreferences(LoginActivity.PREFS_NAME, MODE_PRIVATE);
        currentUserId = prefs.getLong(LoginActivity.KEY_USER_ID, -1);

        userDao = new UserDao(this);
        listView = findViewById(R.id.listView);

        loadUserList();

        // Long press to delete
        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            User user = (User) adapter.getItem(position);

            // Cannot delete yourself
            if (user.getId() == currentUserId) {
                Toast.makeText(this, "Cannot delete current user", Toast.LENGTH_SHORT).show();
                return true;
            }

            // Show delete confirmation dialog
            new AlertDialog.Builder(this)
                    .setTitle("Delete User")
                    .setMessage("Delete user \"" + user.getUsername() + "\"?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        int rows = userDao.deleteUser(user.getId());
                        if (rows > 0) {
                            Toast.makeText(this, "User deleted", Toast.LENGTH_SHORT).show();
                            loadUserList(); // Refresh list
                        } else {
                            Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();

            return true;
        });
    }

    /**
     * Load and display all users
     */
    private void loadUserList() {
        List<User> users = userDao.getAllUsers();
        adapter = new UserListAdapter(this, users);
        listView.setAdapter(adapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Go back
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userDao.close();
    }
}
