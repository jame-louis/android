package com.example.loginapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

/**
 * User Data Access Object
 * Provides all CRUD operations for User with SHA-256 encryption
 */
public class UserDao {

    private DatabaseHelper dbHelper;

    public UserDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    /**
     * Insert new user with encrypted password
     * @return Inserted row ID, -1 if failed
     */
    public long insertUser(User user) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", user.getUsername());
        values.put("password", HashUtil.sha256(user.getPassword()));
        values.put("email", user.getEmail());
        values.put("created_at", user.getCreatedAt());

        return db.insert("users", null, values);
    }

    /**
     * Find user by username
     * @return User object or null if not found
     */
    public User findByUsername(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(
                "users",
                null,
                "username = ?",
                new String[]{username},
                null, null, null
        );

        User user = null;
        if (cursor.moveToFirst()) {
            user = cursorToUser(cursor);
        }
        cursor.close();
        return user;
    }

    /**
     * Authenticate user with username and password
     * @return User object if authenticated, null otherwise
     */
    public User authenticate(String username, String password) {
        User user = findByUsername(username);
        if (user != null && HashUtil.verifyPassword(password, user.getPassword())) {
            return user;
        }
        return null;
    }

    /**
     * Check if username already exists
     */
    public boolean isUsernameExists(String username) {
        return findByUsername(username) != null;
    }

    /**
     * Get all users ordered by registration time (newest first)
     * @return List of all users
     */
    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(
                "users",
                null, null, null, null, null,
                "created_at DESC"
        );

        if (cursor.moveToFirst()) {
            do {
                userList.add(cursorToUser(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return userList;
    }

    /**
     * Delete user by ID
     * @return Number of rows affected
     */
    public int deleteUser(long userId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        return db.delete(
                "users",
                "id = ?",
                new String[]{String.valueOf(userId)}
        );
    }

    /**
     * Convert Cursor to User object
     */
    private User cursorToUser(Cursor cursor) {
        User user = new User();
        user.setId(cursor.getLong(cursor.getColumnIndexOrThrow("id")));
        user.setUsername(cursor.getString(cursor.getColumnIndexOrThrow("username")));
        user.setPassword(cursor.getString(cursor.getColumnIndexOrThrow("password")));
        user.setEmail(cursor.getString(cursor.getColumnIndexOrThrow("email")));
        user.setCreatedAt(cursor.getLong(cursor.getColumnIndexOrThrow("created_at")));
        return user;
    }

    public void close() {
        dbHelper.close();
    }
}
