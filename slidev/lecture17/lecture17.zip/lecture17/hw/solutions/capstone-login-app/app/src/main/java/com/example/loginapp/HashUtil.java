package com.example.loginapp;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Hash Utility Class
 * Provides SHA-256 hashing for password security
 */
public class HashUtil {

    /**
     * Hash string using SHA-256
     * @param input Original string
     * @return 64-character hex hash value, or null if error
     */
    public static String sha256(String input) {
        if (input == null || input.isEmpty()) {
            return null;
        }

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());

            // Convert to hex string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Verify password against stored hash
     * @param inputPassword User-entered plaintext password
     * @param storedHash Hash stored in database
     * @return true if password matches, false otherwise
     */
    public static boolean verifyPassword(String inputPassword, String storedHash) {
        if (inputPassword == null || storedHash == null) {
            return false;
        }
        String inputHash = sha256(inputPassword);
        return storedHash.equals(inputHash);
    }
}
