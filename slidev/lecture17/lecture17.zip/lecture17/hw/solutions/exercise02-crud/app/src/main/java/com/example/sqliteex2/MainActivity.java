package com.example.sqliteex2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Exercise 2: 插入和查询
 * 实现用户注册和登录功能
 */
public class MainActivity extends AppCompatActivity {

    private UserDao userDao;
    private EditText etUsername, etPassword, etEmail;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userDao = new UserDao(this);

        // 初始化视图
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etEmail = findViewById(R.id.etEmail);
        tvResult = findViewById(R.id.tvResult);

        Button btnRegister = findViewById(R.id.btnRegister);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnQuery = findViewById(R.id.btnQuery);

        // 注册按钮
        btnRegister.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            String email = etEmail.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "用户名和密码不能为空", Toast.LENGTH_SHORT).show();
                return;
            }

            User user = new User(username, password, email);
            long id = userDao.insertUser(user);

            if (id > 0) {
                tvResult.setText("注册成功!\nID: " + id);
                Toast.makeText(this, "注册成功", Toast.LENGTH_SHORT).show();
            } else {
                tvResult.setText("注册失败，用户名可能已存在");
                Toast.makeText(this, "注册失败", Toast.LENGTH_SHORT).show();
            }
        });

        // 登录按钮
        btnLogin.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            User user = userDao.findByUsernameAndPassword(username, password);

            if (user != null) {
                tvResult.setText("登录成功!\n" + user.toString());
                Toast.makeText(this, "欢迎 " + user.getUsername(), Toast.LENGTH_SHORT).show();
            } else {
                tvResult.setText("登录失败: 用户名或密码错误");
                Toast.makeText(this, "登录失败", Toast.LENGTH_SHORT).show();
            }
        });

        // 查询按钮
        btnQuery.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();

            if (username.isEmpty()) {
                Toast.makeText(this, "请输入用户名", Toast.LENGTH_SHORT).show();
                return;
            }

            User user = userDao.findByUsername(username);

            if (user != null) {
                tvResult.setText("查询结果:\n" +
                        "用户名: " + user.getUsername() + "\n" +
                        "邮箱: " + user.getEmail() + "\n" +
                        "注册时间: " + user.getCreatedAt());
            } else {
                tvResult.setText("用户不存在: " + username);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userDao.close();
    }
}
