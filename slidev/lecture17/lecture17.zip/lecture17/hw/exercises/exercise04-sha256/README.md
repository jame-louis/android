# Exercise 4: SHA-256密码加密

## 目标
将明文密码存储升级为SHA-256哈希存储。

## 为什么需要加密？

**明文存储的风险：**
```
DB Browser打开app.db → 直接看到密码: "123456"
手机Root后 → 任何人可以读取所有用户密码
```

**哈希后的效果：**
```
密码: "123456"
SHA-256: "8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92"
```

## 基于Exercise 3的修改

### 1. 创建HashUtil工具类

创建 `HashUtil.java`:

```java
package com.example.sqliteex4;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * 哈希工具类
 * 注意: 教学演示用SHA-256，生产环境应使用BCrypt/Argon2
 */
public class HashUtil {

    /**
     * 对字符串进行SHA-256哈希
     * @param input 原始字符串
     * @return 64位十六进制哈希值
     */
    public static String sha256(String input) {
        if (input == null || input.isEmpty()) {
            return null;
        }

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());

            // 转换为十六进制字符串
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 验证密码
     * @param inputPassword 用户输入的明文密码
     * @param storedHash 数据库存储的哈希值
     * @return 是否匹配
     */
    public static boolean verifyPassword(String inputPassword, String storedHash) {
        if (inputPassword == null || storedHash == null) {
            return false;
        }
        String inputHash = sha256(inputPassword);
        return storedHash.equals(inputHash);
    }
}
```

### 2. 修改UserDao

修改 `insertUser()` 方法:
```java
    public long insertUser(User user) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", user.getUsername());
        // 加密存储密码
        values.put("password", HashUtil.sha256(user.getPassword()));
        values.put("email", user.getEmail());
        values.put("created_at", user.getCreatedAt());

        return db.insert("users", null, values);
    }
```

修改 `findByUsernameAndPassword()` 方法:
```java
    public User findByUsernameAndPassword(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // 先根据用户名查找
        User user = findByUsername(username);

        if (user != null) {
            // 验证密码哈希
            if (HashUtil.verifyPassword(password, user.getPassword())) {
                return user;
            }
        }
        return null;
    }
```

修改 `updatePassword()` 方法:
```java
    public int updatePassword(long userId, String newPassword) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        // 加密新密码
        values.put("password", HashUtil.sha256(newPassword));

        return db.update(
            "users",
            values,
            "id = ?",
            new String[]{String.valueOf(userId)}
        );
    }
```

### 3. 修改MainActivity添加对比演示

```java
package com.example.sqliteex4;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private UserDao userDao;
    private EditText etPassword;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userDao = new UserDao(this);

        etPassword = findViewById(R.id.etPassword);
        tvResult = findViewById(R.id.tvResult);

        Button btnHashDemo = findViewById(R.id.btnHashDemo);
        Button btnRegister = findViewById(R.id.btnRegister);
        Button btnLogin = findViewById(R.id.btnLogin);

        // 哈希演示
        btnHashDemo.setOnClickListener(v -> {
            String password = etPassword.getText().toString();
            if (password.isEmpty()) {
                Toast.makeText(this, "请输入密码", Toast.LENGTH_SHORT).show();
                return;
            }

            String hash = HashUtil.sha256(password);
            tvResult.setText(
                "原始密码: " + password + "\n\n" +
                "SHA-256哈希:\n" + hash + "\n\n" +
                "长度: " + hash.length() + " 字符"
            );
        });

        // 注册(使用加密)
        btnRegister.setOnClickListener(v -> {
            String username = "testuser";
            String password = etPassword.getText().toString();

            if (password.isEmpty()) {
                Toast.makeText(this, "请输入密码", Toast.LENGTH_SHORT).show();
                return;
            }

            User user = new User(username, password, "test@test.com");
            long id = userDao.insertUser(user);

            if (id > 0) {
                tvResult.setText(
                    "注册成功!\nID: " + id + "\n\n" +
                    "数据库中存储的密码:\n" + HashUtil.sha256(password) + "\n\n" +
                    "(即使看到数据库也无法知道原始密码)"
                );
            } else {
                tvResult.setText("注册失败");
            }
        });

        // 登录验证
        btnLogin.setOnClickListener(v -> {
            String username = "testuser";
            String password = etPassword.getText().toString();

            User user = userDao.findByUsernameAndPassword(username, password);

            if (user != null) {
                tvResult.setText("登录成功!\n欢迎 " + user.getUsername());
            } else {
                tvResult.setText("登录失败: 密码错误或用户不存在");
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userDao.close();
    }
}
```

### 4. 修改activity_main.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<ScrollView
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:padding="16dp">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Exercise 4: SHA-256加密"
            android:textSize="20sp"
            android:textStyle="bold" />

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="输入密码查看SHA-256哈希效果"
            android:layout_marginTop="8dp"
            android:textColor="#666" />

        <EditText
            android:id="@+id/etPassword"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="输入密码"
            android:inputType="textPassword"
            android:layout_marginTop="16dp" />

        <Button
            android:id="@+id/btnHashDemo"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:text="查看哈希值"
            android:layout_marginTop="16dp" />

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:layout_marginTop="16dp">

            <Button
                android:id="@+id/btnRegister"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="注册(加密存储)" />

            <Button
                android:id="@+id/btnLogin"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="登录(哈希验证)" />

        </LinearLayout>

        <TextView
            android:id="@+id/tvResult"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="24dp"
            android:padding="16dp"
            android:background="#f0f0f0"
            android:textIsSelectable="true"
            android:text="结果将显示在这里" />

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="24dp"
            android:text="安全提示:\n\n1. SHA-256是单向哈希，无法反推出原始密码\n2. 相同输入总是产生相同哈希\n3. 生产环境推荐使用BCrypt或Argon2"
            android:textSize="12sp"
            android:textColor="#666" />

    </LinearLayout>
</ScrollView>
```

## 验证步骤

1. 输入"123456"，点击"查看哈希值"
2. 观察64位哈希字符串
3. 点击"注册(加密存储)"
4. 打开DB Browser验证存储的是哈希而非明文
5. 点击"登录(哈希验证)"验证能正常登录

## 成功标准

- [ ] 能看到密码的SHA-256哈希值
- [ ] 数据库中密码字段存储为64位哈希
- [ ] 相同密码登录验证成功
- [ ] 不同密码登录验证失败

## 生产环境建议

```java
// 教学用: SHA-256 (简单演示)
// 生产环境推荐:

// 1. BCrypt (最常用)
// implementation 'org.mindrot:jbcrypt:0.4'
// String hashed = BCrypt.hashpw(password, BCrypt.gensalt());
// boolean match = BCrypt.checkpw(password, hashed);

// 2. AndroidX Security (Google推荐)
// implementation 'androidx.security:security-crypto:1.1.0-alpha06'
```

## 下一步

完成Capstone: 完整登录注册App
