# Exercise 3: 更新和删除 (UD之Update, Delete)

## 目标
实现用户信息修改和删除功能。

## 基于Exercise 2的修改

### 1. 在UserDao中添加新方法

在 `UserDao.java` 中添加:

```java
    /**
     * 更新用户信息
     * @return 受影响的行数
     */
    public int updateUser(User user) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("email", user.getEmail());
        // 注意: 实际项目中密码更新需要单独处理

        // whereClause: id = ?
        // whereArgs: [user.getId()]
        return db.update(
            "users",
            values,
            "id = ?",
            new String[]{String.valueOf(user.getId())}
        );
    }

    /**
     * 修改密码
     */
    public int updatePassword(long userId, String newPassword) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("password", newPassword);

        return db.update(
            "users",
            values,
            "id = ?",
            new String[]{String.valueOf(userId)}
        );
    }

    /**
     * 删除用户
     * @return 受影响的行数
     */
    public int deleteUser(long userId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        return db.delete(
            "users",
            "id = ?",
            new String[]{String.valueOf(userId)}
        );
    }

    /**
     * 获取所有用户
     */
    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(
            "users",
            null, null, null, null, null,
            "created_at DESC"  // 按注册时间倒序
        );

        if (cursor.moveToFirst()) {
            do {
                userList.add(cursorToUser(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return userList;
    }
```

添加List导入:
```java
import java.util.ArrayList;
import java.util.List;
```

### 2. 修改MainActivity

```java
package com.example.sqliteex3;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private UserDao userDao;
    private EditText etUserId, etUsername, etPassword, etEmail;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userDao = new UserDao(this);

        // 初始化视图
        etUserId = findViewById(R.id.etUserId);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etEmail = findViewById(R.id.etEmail);
        tvResult = findViewById(R.id.tvResult);

        Button btnInsert = findViewById(R.id.btnInsert);
        Button btnUpdate = findViewById(R.id.btnUpdate);
        Button btnDelete = findViewById(R.id.btnDelete);
        Button btnList = findViewById(R.id.btnList);

        // 插入示例数据
        btnInsert.setOnClickListener(v -> insertSampleData());

        // 更新用户
        btnUpdate.setOnClickListener(v -> {
            String idStr = etUserId.getText().toString().trim();
            String email = etEmail.getText().toString().trim();

            if (idStr.isEmpty()) {
                Toast.makeText(this, "请输入用户ID", Toast.LENGTH_SHORT).show();
                return;
            }

            User user = new User();
            user.setId(Long.parseLong(idStr));
            user.setEmail(email);

            int rows = userDao.updateUser(user);
            tvResult.setText("更新了 " + rows + " 行");
        });

        // 删除用户
        btnDelete.setOnClickListener(v -> {
            String idStr = etUserId.getText().toString().trim();

            if (idStr.isEmpty()) {
                Toast.makeText(this, "请输入用户ID", Toast.LENGTH_SHORT).show();
                return;
            }

            int rows = userDao.deleteUser(Long.parseLong(idStr));
            tvResult.setText("删除了 " + rows + " 行");
        });

        // 列出所有用户
        btnList.setOnClickListener(v -> {
            List<User> users = userDao.getAllUsers();
            StringBuilder sb = new StringBuilder();
            sb.append("共 ").append(users.size()).append(" 个用户:\n\n");

            for (User u : users) {
                sb.append("ID:").append(u.getId())
                  .append(" | ").append(u.getUsername())
                  .append(" | ").append(u.getEmail())
                  .append("\n");
            }

            tvResult.setText(sb.toString());
        });
    }

    private void insertSampleData() {
        // 插入3个示例用户
        User u1 = new User("alice", "123456", "alice@example.com");
        User u2 = new User("bob", "123456", "bob@example.com");
        User u3 = new User("charlie", "123456", "charlie@example.com");

        userDao.insertUser(u1);
        userDao.insertUser(u2);
        long id3 = userDao.insertUser(u3);

        tvResult.setText("插入示例数据完成!\n第三个用户ID: " + id3);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userDao.close();
    }
}
```

### 3. 修改activity_main.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<ScrollView
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:padding="16dp">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Exercise 3: 更新和删除"
            android:textSize="20sp"
            android:textStyle="bold" />

        <Button
            android:id="@+id/btnInsert"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:text="插入示例数据"
            android:layout_marginTop="16dp" />

        <EditText
            android:id="@+id/etUserId"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="用户ID (用于更新/删除)"
            android:inputType="number"
            android:layout_marginTop="16dp" />

        <EditText
            android:id="@+id/etUsername"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="用户名(只读)"
            android:enabled="false" />

        <EditText
            android:id="@+id/etPassword"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="密码"
            android:inputType="textPassword" />

        <EditText
            android:id="@+id/etEmail"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="新邮箱"
            android:inputType="textEmailAddress" />

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:layout_marginTop="16dp">

            <Button
                android:id="@+id/btnUpdate"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="更新邮箱" />

            <Button
                android:id="@+id/btnDelete"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="删除用户" />

            <Button
                android:id="@+id/btnList"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="列出全部" />

        </LinearLayout>

        <TextView
            android:id="@+id/tvResult"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="24dp"
            android:padding="16dp"
            android:background="#f0f0f0"
            android:text="点击按钮操作数据库" />

    </LinearLayout>
</ScrollView>
```

## 验证步骤

1. 点击"插入示例数据" → 看到插入成功的ID
2. 点击"列出全部" → 看到3个用户
3. 输入ID=1，新邮箱，点击"更新邮箱" → 验证成功
4. 再次"列出全部" → 验证邮箱已改
5. 输入ID=2，点击"删除用户" → 验证删除成功
6. 在DB Browser中验证数据变化

## 成功标准

- [ ] 能批量插入示例数据
- [ ] 能修改用户邮箱
- [ ] 能删除指定用户
- [ ] 能列出所有用户

## 关键API

| 方法 | 作用 | 返回值 |
|-----|------|-------|
| `db.update()` | 修改数据 | 受影响行数 |
| `db.delete()` | 删除数据 | 受影响行数 |
| `cursor.moveToNext()` | 移动到下一条 | boolean |

## 下一步

完成Exercise 4: SHA-256加密
