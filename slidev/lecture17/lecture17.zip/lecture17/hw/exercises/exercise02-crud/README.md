# Exercise 2: 插入和查询 (CR之Create, Read)

## 目标
实现用户注册(插入)和登录查询功能。

## 基于Exercise 1的修改

### 1. 创建User模型类

创建 `User.java`:

```java
package com.example.sqliteex2;

public class User {
    private long id;
    private String username;
    private String password;
    private String email;
    private long createdAt;

    public User() {}

    public User(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.createdAt = System.currentTimeMillis();
    }

    // Getters and Setters
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return "User{id=" + id + ", username='" + username + "', email='" + email + "'}";
    }
}
```

### 2. 创建UserDao类

创建 `UserDao.java`:

```java
package com.example.sqliteex2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserDao {

    private DatabaseHelper dbHelper;

    public UserDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    /**
     * 插入用户
     * @return 插入的行ID，-1表示失败
     */
    public long insertUser(User user) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", user.getUsername());
        values.put("password", user.getPassword());
        values.put("email", user.getEmail());
        values.put("created_at", user.getCreatedAt());

        // 参数: 表名, nullColumnHack, values
        return db.insert("users", null, values);
    }

    /**
     * 根据用户名查找用户
     * @return User对象，未找到返回null
     */
    public User findByUsername(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // 参数化查询防止SQL注入
        Cursor cursor = db.query(
            "users",                          // 表名
            null,                             // 所有列
            "username = ?",                   // where条件
            new String[]{username},           // where参数
            null, null, null                  // groupBy, having, orderBy
        );

        User user = null;
        if (cursor.moveToFirst()) {
            user = cursorToUser(cursor);
        }
        cursor.close();
        return user;
    }

    /**
     * 根据用户名和密码查找（登录验证）
     */
    public User findByUsernameAndPassword(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(
            "users",
            null,
            "username = ? AND password = ?",
            new String[]{username, password},
            null, null, null
        );

        User user = null;
        if (cursor.moveToFirst()) {
            user = cursorToUser(cursor);
        }
        cursor.close();
        return user;
    }

    /**
     * 将Cursor转换为User对象
     */
    private User cursorToUser(Cursor cursor) {
        User user = new User();
        user.setId(cursor.getLong(cursor.getColumnIndexOrThrow("id")));
        user.setUsername(cursor.getString(cursor.getColumnIndexOrThrow("username")));
        user.setPassword(cursor.getString(cursor.getColumnIndexOrThrow("password")));
        user.setEmail(cursor.getString(cursor.getColumnIndexOrThrow("email")));
        user.setCreatedAt(cursor.getLong(cursor.getColumnIndexOrThrow("created_at")));
        return user;
    }

    public void close() {
        dbHelper.close();
    }
}
```

### 3. DatabaseHelper（复用Exercise 1的代码）

### 4. 修改MainActivity

```java
package com.example.sqliteex2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private UserDao userDao;
    private EditText etUsername, etPassword, etEmail;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userDao = new UserDao(this);

        // 初始化视图
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etEmail = findViewById(R.id.etEmail);
        etEmail = findViewById(R.id.etEmail);
        tvResult = findViewById(R.id.tvResult);
        Button btnRegister = findViewById(R.id.btnRegister);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnQuery = findViewById(R.id.btnQuery);

        // 注册按钮
        btnRegister.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            String email = etEmail.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "用户名和密码不能为空", Toast.LENGTH_SHORT).show();
                return;
            }

            User user = new User(username, password, email);
            long id = userDao.insertUser(user);

            if (id > 0) {
                tvResult.setText("注册成功!\nID: " + id);
                Toast.makeText(this, "注册成功", Toast.LENGTH_SHORT).show();
            } else {
                tvResult.setText("注册失败，用户名可能已存在");
                Toast.makeText(this, "注册失败", Toast.LENGTH_SHORT).show();
            }
        });

        // 登录按钮
        btnLogin.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            User user = userDao.findByUsernameAndPassword(username, password);

            if (user != null) {
                tvResult.setText("登录成功!\n" + user.toString());
                Toast.makeText(this, "欢迎 " + user.getUsername(), Toast.LENGTH_SHORT).show();
            } else {
                tvResult.setText("登录失败: 用户名或密码错误");
                Toast.makeText(this, "登录失败", Toast.LENGTH_SHORT).show();
            }
        });

        // 查询按钮
        btnQuery.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();

            if (username.isEmpty()) {
                Toast.makeText(this, "请输入用户名", Toast.LENGTH_SHORT).show();
                return;
            }

            User user = userDao.findByUsername(username);

            if (user != null) {
                tvResult.setText("查询结果:\n" +
                    "用户名: " + user.getUsername() + "\n" +
                    "邮箱: " + user.getEmail() + "\n" +
                    "注册时间: " + user.getCreatedAt());
            } else {
                tvResult.setText("用户不存在: " + username);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userDao.close();
    }
}
```

### 5. 修改activity_main.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<ScrollView
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:padding="16dp">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Exercise 2: 插入和查询"
            android:textSize="20sp"
            android:textStyle="bold" />

        <EditText
            android:id="@+id/etUsername"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="用户名"
            android:layout_marginTop="16dp" />

        <EditText
            android:id="@+id/etPassword"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="密码"
            android:inputType="textPassword"
            android:layout_marginTop="8dp" />

        <EditText
            android:id="@+id/etEmail"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="邮箱(可选)"
            android:inputType="textEmailAddress"
            android:layout_marginTop="8dp" />

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:layout_marginTop="16dp">

            <Button
                android:id="@+id/btnRegister"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="注册" />

            <Button
                android:id="@+id/btnLogin"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="登录" />

            <Button
                android:id="@+id/btnQuery"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="查询" />

        </LinearLayout>

        <TextView
            android:id="@+id/tvResult"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="24dp"
            android:padding="16dp"
            android:background="#f0f0f0"
            android:text="结果将显示在这里" />

    </LinearLayout>
</ScrollView>
```

## 验证步骤

1. 输入用户名、密码、邮箱，点击**注册**
2. 看到"注册成功"，记录ID
3. 点击**查询**，验证信息正确
4. 点击**登录**，验证成功
5. 修改密码再次登录，验证失败
6. 在DB Browser中查看数据是否正确存储

## 成功标准

- [ ] 能成功注册用户
- [ ] 用户名重复时注册失败
- [ ] 能正确查询用户信息
- [ ] 登录验证逻辑正确

## 关键概念

1. **ContentValues**: 键值对存储，用于insert/update
2. **Cursor**: 查询结果集，需要moveToFirst()和close()
3. **参数化查询**: `?`占位符防止SQL注入
4. **getWritableDatabase/getReadableDatabase**: 获取数据库实例

## 下一步

完成Exercise 3: 更新和删除
