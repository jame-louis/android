# Exercise 1: 创建数据库

## 目标
创建SQLite数据库和users表，验证数据库文件正确生成。

## 步骤

### 1. 创建新项目
- File → New → New Project → Empty Views Activity
- Name: `SQLiteEx1`
- Language: Java
- Minimum SDK: API 20

### 2. 创建DatabaseHelper类

创建 `DatabaseHelper.java`:

```java
package com.example.sqliteex1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // 数据库信息
    private static final String DATABASE_NAME = "app.db";
    private static final int DATABASE_VERSION = 1;

    // 建表SQL
    private static final String CREATE_USERS_TABLE =
        "CREATE TABLE users (" +
        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
        "username TEXT UNIQUE NOT NULL, " +
        "password TEXT NOT NULL, " +
        "email TEXT, " +
        "created_at INTEGER DEFAULT 0" +
        ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 首次创建数据库时执行
        db.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 数据库版本升级时执行
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }
}
```

### 3. 修改MainActivity

```java
package com.example.sqliteex1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = findViewById(R.id.tvStatus);
        Button btnCreateDb = findViewById(R.id.btnCreateDb);

        btnCreateDb.setOnClickListener(v -> {
            try {
                // 实例化DatabaseHelper会触发onCreate
                dbHelper = new DatabaseHelper(this);
                tvStatus.setText("数据库创建成功!\n名称: app.db\n版本: 1");
                Toast.makeText(this, "数据库创建成功", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                tvStatus.setText("错误: " + e.getMessage());
                Toast.makeText(this, "创建失败", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}
```

### 4. 修改activity_main.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="24dp"
    android:gravity="center">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Exercise 1: 创建数据库"
        android:textSize="20sp"
        android:textStyle="bold" />

    <Button
        android:id="@+id/btnCreateDb"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="创建数据库"
        android:layout_marginTop="32dp" />

    <TextView
        android:id="@+id/tvStatus"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="24dp"
        android:text="点击按钮创建数据库"
        android:textSize="14sp"
        android:padding="16dp"
        android:background="#f0f0f0" />

</LinearLayout>
```

## 验证步骤

1. 运行App，点击"创建数据库"
2. 看到"数据库创建成功"提示
3. 打开Device File Explorer:
   - 路径: `/data/data/com.example.sqliteex1/databases/`
   - 验证存在: `app.db` 和 `app.db-journal`
4. 右键`app.db` → Save As，用DB Browser for SQLite打开
5. 验证表结构正确

## 成功标准

- [ ] 数据库文件生成成功
- [ ] users表结构正确（5个字段）
- [ ] 点击按钮状态文本更新

## 下一步

完成Exercise 2: 插入和查询
