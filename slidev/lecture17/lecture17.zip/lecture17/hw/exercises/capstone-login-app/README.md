# Capstone: 完整登录注册应用

## 目标
构建完整的4页面用户管理系统。

## 功能清单

| 页面 | 功能 |
|-----|------|
| LoginActivity | 登录验证、跳转注册、跳转主页 |
| RegisterActivity | 用户名唯一校验、邮箱格式验证、注册成功后返回登录 |
| HomeActivity | 显示当前用户信息、退出登录、查看用户列表 |
| UserListActivity | 显示所有注册用户、长按删除 |

## 项目结构

```
java/com/example/loginapp/
├── DatabaseHelper.java
├── User.java
├── UserDao.java
├── HashUtil.java
├── LoginActivity.java
├── RegisterActivity.java
├── HomeActivity.java
└── UserListActivity.java

res/layout/
├── activity_login.xml
├── activity_register.xml
├── activity_home.xml
└── activity_user_list.xml
```

## 1. 核心类（复用Exercise 4代码）

### DatabaseHelper.java
```java
package com.example.loginapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "login.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "username TEXT UNIQUE NOT NULL," +
            "password TEXT NOT NULL," +
            "email TEXT," +
            "created_at INTEGER DEFAULT 0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }
}
```

### User.java
```java
package com.example.loginapp;

public class User {
    private long id;
    private String username;
    private String password;
    private String email;
    private long createdAt;

    public User() {}

    public User(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.createdAt = System.currentTimeMillis();
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
}
```

### HashUtil.java
```java
package com.example.loginapp;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashUtil {
    public static String sha256(String input) {
        if (input == null || input.isEmpty()) return null;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) {
                String h = Integer.toHexString(0xff & b);
                if (h.length() == 1) hex.append('0');
                hex.append(h);
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    public static boolean verify(String input, String hash) {
        if (input == null || hash == null) return false;
        return hash.equals(sha256(input));
    }
}
```

### UserDao.java
```java
package com.example.loginapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
    private DatabaseHelper helper;

    public UserDao(Context context) {
        helper = new DatabaseHelper(context);
    }

    public long insert(User user) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("username", user.getUsername());
        v.put("password", HashUtil.sha256(user.getPassword()));
        v.put("email", user.getEmail());
        v.put("created_at", user.getCreatedAt());
        return db.insert("users", null, v);
    }

    public User findByUsername(String username) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query("users", null, "username=?",
            new String[]{username}, null, null, null);
        User u = null;
        if (c.moveToFirst()) {
            u = toUser(c);
        }
        c.close();
        return u;
    }

    public User findByCredentials(String username, String password) {
        User u = findByUsername(username);
        if (u != null && HashUtil.verify(password, u.getPassword())) {
            return u;
        }
        return null;
    }

    public List<User> getAll() {
        List<User> list = new ArrayList<>();
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query("users", null, null, null, null, null, "id DESC");
        while (c.moveToNext()) {
            list.add(toUser(c));
        }
        c.close();
        return list;
    }

    public int delete(long id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        return db.delete("users", "id=?", new String[]{String.valueOf(id)});
    }

    private User toUser(Cursor c) {
        User u = new User();
        u.setId(c.getLong(c.getColumnIndexOrThrow("id")));
        u.setUsername(c.getString(c.getColumnIndexOrThrow("username")));
        u.setPassword(c.getString(c.getColumnIndexOrThrow("password")));
        u.setEmail(c.getString(c.getColumnIndexOrThrow("email")));
        u.setCreatedAt(c.getLong(c.getColumnIndexOrThrow("created_at")));
        return u;
    }

    public void close() { helper.close(); }
}
```

## 2. Activity类

### LoginActivity.java
```java
package com.example.loginapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private UserDao userDao;
    public static final String PREFS_NAME = "LoginPrefs";
    public static final String KEY_USER_ID = "user_id";
    public static final String KEY_USERNAME = "username";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 检查是否已登录
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        if (prefs.contains(KEY_USER_ID)) {
            startActivity(new Intent(this, HomeActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_login);

        userDao = new UserDao(this);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnGoRegister = findViewById(R.id.btnGoRegister);

        btnLogin.setOnClickListener(v -> login());
        btnGoRegister.setOnClickListener(v -> {
            startActivity(new Intent(this, RegisterActivity.class));
        });
    }

    private void login() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "请填写完整", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = userDao.findByCredentials(username, password);

        if (user != null) {
            // 保存登录状态到SharedPreferences
            SharedPreferences.Editor editor =
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
            editor.putLong(KEY_USER_ID, user.getId());
            editor.putString(KEY_USERNAME, user.getUsername());
            editor.apply();

            Toast.makeText(this, "欢迎 " + username, Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, HomeActivity.class));
            finish();
        } else {
            Toast.makeText(this, "用户名或密码错误", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userDao.close();
    }
}
```

### activity_login.xml
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    android:padding="32dp">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="用户登录"
        android:textSize="28sp"
        android:textStyle="bold" />

    <EditText
        android:id="@+id/etUsername"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="用户名"
        android:layout_marginTop="32dp" />

    <EditText
        android:id="@+id/etPassword"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="密码"
        android:inputType="textPassword"
        android:layout_marginTop="16dp" />

    <Button
        android:id="@+id/btnLogin"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="登录"
        android:layout_marginTop="24dp" />

    <Button
        android:id="@+id/btnGoRegister"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="没有账号? 去注册"
        android:layout_marginTop="8dp" />

</LinearLayout>
```

### RegisterActivity.java
```java
package com.example.loginapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private EditText etUsername, etPassword, etEmail;
    private UserDao userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        userDao = new UserDao(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etEmail = findViewById(R.id.etEmail);
        Button btnRegister = findViewById(R.id.btnRegister);
        Button btnBack = findViewById(R.id.btnBack);

        btnRegister.setOnClickListener(v -> register());
        btnBack.setOnClickListener(v -> finish());
    }

    private void register() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString();
        String email = etEmail.getText().toString().trim();

        // 验证
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "用户名和密码不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        if (username.length() < 3) {
            Toast.makeText(this, "用户名至少3位", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 6) {
            Toast.makeText(this, "密码至少6位", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!email.isEmpty() && !email.contains("@")) {
            Toast.makeText(this, "邮箱格式错误", Toast.LENGTH_SHORT).show();
            return;
        }

        // 检查用户名是否存在
        if (userDao.findByUsername(username) != null) {
            Toast.makeText(this, "用户名已存在", Toast.LENGTH_SHORT).show();
            return;
        }

        // 注册
        User user = new User(username, password, email);
        long id = userDao.insert(user);

        if (id > 0) {
            Toast.makeText(this, "注册成功!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "注册失败", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userDao.close();
    }
}
```

### activity_register.xml
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="32dp">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="用户注册"
        android:textSize="28sp"
        android:textStyle="bold" />

    <EditText
        android:id="@+id/etUsername"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="用户名 (至少3位)"
        android:layout_marginTop="32dp" />

    <EditText
        android:id="@+id/etPassword"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="密码 (至少6位)"
        android:inputType="textPassword"
        android:layout_marginTop="16dp" />

    <EditText
        android:id="@+id/etEmail"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="邮箱 (可选)"
        android:inputType="textEmailAddress"
        android:layout_marginTop="16dp" />

    <Button
        android:id="@+id/btnRegister"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="注册"
        android:layout_marginTop="24dp" />

    <Button
        android:id="@+id/btnBack"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="返回登录"
        android:layout_marginTop="8dp" />

</LinearLayout>
```

### HomeActivity.java
```java
package com.example.loginapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private TextView tvWelcome;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        prefs = getSharedPreferences(LoginActivity.PREFS_NAME, MODE_PRIVATE);

        // 检查登录状态
        long userId = prefs.getLong(LoginActivity.KEY_USER_ID, -1);
        if (userId == -1) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        tvWelcome = findViewById(R.id.tvWelcome);
        Button btnUserList = findViewById(R.id.btnUserList);
        Button btnLogout = findViewById(R.id.btnLogout);

        String username = prefs.getString(LoginActivity.KEY_USERNAME, "用户");
        tvWelcome.setText("欢迎回来, " + username + "!");

        btnUserList.setOnClickListener(v -> {
            startActivity(new Intent(this, UserListActivity.class));
        });

        btnLogout.setOnClickListener(v -> logout());
    }

    private void logout() {
        // 清除登录状态
        prefs.edit().clear().apply();
        Toast.makeText(this, "已退出登录", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }
}
```

### activity_home.xml
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    android:padding="32dp">

    <TextView
        android:id="@+id/tvWelcome"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="欢迎回来!"
        android:textSize="24sp"
        android:textStyle="bold" />

    <Button
        android:id="@+id/btnUserList"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="查看用户列表"
        android:layout_marginTop="32dp" />

    <Button
        android:id="@+id/btnLogout"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="退出登录"
        android:layout_marginTop="16dp" />

</LinearLayout>
```

### UserListActivity.java
```java
package com.example.loginapp;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class UserListActivity extends AppCompatActivity {

    private ListView lvUsers;
    private UserDao userDao;
    private List<User> userList;
    private UserAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_list);

        userDao = new UserDao(this);
        lvUsers = findViewById(R.id.lvUsers);
        Button btnBack = findViewById(R.id.btnBack);

        loadUsers();

        btnBack.setOnClickListener(v -> finish());

        // 长按删除
        lvUsers.setOnItemLongClickListener((parent, view, pos, id) -> {
            User u = userList.get(pos);
            new AlertDialog.Builder(this)
                .setTitle("确认删除")
                .setMessage("删除用户: " + u.getUsername() + "?")
                .setPositiveButton("删除", (d, w) -> {
                    userDao.delete(u.getId());
                    loadUsers();
                    Toast.makeText(this, "已删除", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
            return true;
        });
    }

    private void loadUsers() {
        userList = userDao.getAll();
        adapter = new UserAdapter();
        lvUsers.setAdapter(adapter);
    }

    class UserAdapter extends BaseAdapter {
        @Override
        public int getCount() { return userList.size(); }

        @Override
        public Object getItem(int pos) { return userList.get(pos); }

        @Override
        public long getItemId(int pos) { return userList.get(pos).getId(); }

        @Override
        public View getView(int pos, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(UserListActivity.this)
                    .inflate(android.R.layout.simple_list_item_2, parent, false);
            }

            User u = userList.get(pos);
            TextView tv1 = convertView.findViewById(android.R.id.text1);
            TextView tv2 = convertView.findViewById(android.R.id.text2);

            tv1.setText(u.getUsername() + (u.getEmail() != null ? " (" + u.getEmail() + ")" : ""));
            tv2.setText("ID: " + u.getId() + " | 长按删除");

            return convertView;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userDao.close();
    }
}
```

### activity_user_list.xml
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="16dp">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="用户列表 (长按删除)"
        android:textSize="20sp"
        android:textStyle="bold" />

    <ListView
        android:id="@+id/lvUsers"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1"
        android:layout_marginTop="16dp" />

    <Button
        android:id="@+id/btnBack"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="返回" />

</LinearLayout>
```

## 3. AndroidManifest.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.loginapp">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="LoginApp"
        android:theme="@style/Theme.AppCompat.Light.DarkActionBar">

        <activity
            android:name=".LoginActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <activity android:name=".RegisterActivity" />
        <activity android:name=".HomeActivity" />
        <activity android:name=".UserListActivity" />

    </application>
</manifest>
```

## 验证步骤

1. **注册**: 创建2-3个不同用户
2. **登录**: 验证正确/错误密码
3. **主页**: 显示欢迎信息
4. **用户列表**: 查看所有用户
5. **删除**: 长按删除某个用户
6. **退出**: 验证回到登录页
7. **持久登录**: 关闭App重开，自动进入主页

## 成功标准

- [ ] 能注册多个用户
- [ ] 用户名重复时提示
- [ ] 密码错误时登录失败
- [ ] 登录后显示主页
- [ ] 能查看用户列表
- [ ] 能删除用户
- [ ] 退出后需重新登录
- [ ] 数据库中密码为哈希值
