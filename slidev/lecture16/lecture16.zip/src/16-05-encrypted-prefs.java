package com.example.sharedprefsdemo;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.io.IOException;
import java.security.GeneralSecurityException;

/**
 * 加密偏好设置管理类
 * 用于存储敏感信息（Token、密码等）
 */
public class SecurePreferences {

    private static final String FILE_NAME = "secure_prefs";
    private static SecurePreferences instance;
    private final SharedPreferences encryptedPrefs;

    public static synchronized SecurePreferences getInstance(Context context) {
        if (instance == null) {
            try {
                instance = new SecurePreferences(context.getApplicationContext());
            } catch (Exception e) {
                throw new RuntimeException("初始化加密存储失败", e);
            }
        }
        return instance;
    }

    private SecurePreferences(Context context) throws GeneralSecurityException, IOException {
        // 创建或获取主密钥
        MasterKey masterKey = new MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build();

        // 创建加密的 SharedPreferences
        encryptedPrefs = EncryptedSharedPreferences.create(
            context,
            FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        );
    }

    public void saveToken(String token) {
        encryptedPrefs.edit().putString("auth_token", token).apply();
    }

    public String getToken() {
        return encryptedPrefs.getString("auth_token", null);
    }

    public void clearToken() {
        encryptedPrefs.edit().remove("auth_token").apply();
    }
}
