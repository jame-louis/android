// 获取 CheckBox 实例
cbRemember = findViewById(R.id.cb_remember);

// 设置选中状态
cbRemember.setChecked(true);   // 选中
cbRemember.setChecked(false);  // 取消选中

// 获取当前状态
boolean isChecked = cbRemember.isChecked();

// 切换状态（选中变未选，未选变选中）
cbRemember.toggle();

// 启用/禁用
cbRemember.setEnabled(false);  // 禁用（灰色）
cbRemember.setEnabled(true);   // 启用

// 监听状态变化
cbRemember.setOnCheckedChangeListener((buttonView, isChecked) -> {
    if (isChecked) {
        Toast.makeText(LoginActivity.this, "已勾选记住用户名", Toast.LENGTH_SHORT).show();
    } else {
        Toast.makeText(LoginActivity.this, "已取消记住用户名", Toast.LENGTH_SHORT).show();
    }
});
