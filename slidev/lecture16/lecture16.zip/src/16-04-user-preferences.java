package com.example.sharedprefsdemo;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 用户偏好设置管理类
 * 单例模式，集中管理所有用户相关配置
 */
public class UserPreferences {

    private static final String PREFS_NAME = "UserPrefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_REMEMBER = "remember";
    private static final String KEY_LOGIN_COUNT = "login_count";
    private static final String KEY_LAST_LOGIN_TIME = "last_login_time";

    private static UserPreferences instance;
    private final SharedPreferences prefs;

    // 单例获取
    public static synchronized UserPreferences getInstance(Context context) {
        if (instance == null) {
            instance = new UserPreferences(context.getApplicationContext());
        }
        return instance;
    }

    private UserPreferences(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // ========== 用户名相关 ==========

    public void setUsername(String username) {
        prefs.edit().putString(KEY_USERNAME, username).apply();
    }

    public String getUsername() {
        return prefs.getString(KEY_USERNAME, "");
    }

    public void clearUsername() {
        prefs.edit().remove(KEY_USERNAME).apply();
    }

    // ========== 记住我相关 ==========

    public void setRememberMe(boolean remember) {
        prefs.edit().putBoolean(KEY_REMEMBER, remember).apply();
    }

    public boolean isRememberMe() {
        return prefs.getBoolean(KEY_REMEMBER, false);
    }

    // ========== 统计相关 ==========

    public void recordLogin() {
        int count = getLoginCount();
        prefs.edit()
            .putInt(KEY_LOGIN_COUNT, count + 1)
            .putLong(KEY_LAST_LOGIN_TIME, System.currentTimeMillis())
            .apply();
    }

    public int getLoginCount() {
        return prefs.getInt(KEY_LOGIN_COUNT, 0);
    }

    public long getLastLoginTime() {
        return prefs.getLong(KEY_LAST_LOGIN_TIME, 0);
    }

    // ========== 通用方法 ==========

    public void clearAll() {
        prefs.edit().clear().apply();
    }
}
