package com.example.sharedprefsdemo;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "UserPrefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_REMEMBER = "remember";

    private EditText etUsername;
    private EditText etPassword;
    private CheckBox cbRemember;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 初始化视图
        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        cbRemember = findViewById(R.id.cb_remember);
        btnLogin = findViewById(R.id.btn_login);

        // 读取保存的用户名
        loadSavedUsername();

        // 设置登录按钮点击事件
        btnLogin.setOnClickListener(v -> performLogin());
    }

    /**
     * 从 SharedPreferences 加载保存的用户名
     */
    private void loadSavedUsername() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean remember = prefs.getBoolean(KEY_REMEMBER, false);

        if (remember) {
            String username = prefs.getString(KEY_USERNAME, "");
            etUsername.setText(username);
            cbRemember.setChecked(true);
        }
    }

    /**
     * 执行登录逻辑
     */
    private void performLogin() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString();
        boolean remember = cbRemember.isChecked();

        // 简单验证
        if (username.isEmpty()) {
            etUsername.setError("用户名不能为空");
            return;
        }

        // 保存用户偏好
        savePreferences(username, remember);

        // 模拟登录成功
        Toast.makeText(this, "登录成功！", Toast.LENGTH_SHORT).show();
    }

    /**
     * 保存到 SharedPreferences
     */
    private void savePreferences(String username, boolean remember) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        if (remember) {
            editor.putString(KEY_USERNAME, username);
            editor.putBoolean(KEY_REMEMBER, true);
        } else {
            // 不记住则清除之前保存的用户名
            editor.remove(KEY_USERNAME);
            editor.putBoolean(KEY_REMEMBER, false);
        }

        editor.apply();  // 异步保存，不阻塞主线程
    }
}
